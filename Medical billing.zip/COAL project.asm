.MODEL SMALL
.STACK 100H
.DATA 
    WELCOME DB "                 WELCOME TO MEDICAL STORE MANAGEMENT SYSTEM$"
    OPTION DB 10,13,10,13,"ENTER 1 FOR PRODUCT'S SALE ",10,13,"ENTER 2 FOR PRODUCT DETAILS ",10,13,"ENTER 0 TO END THE PROGRAM $"  
    CUSTOMERCHOICE DB 10,13,10,13,"ENTER 1 FOR PONSTAN ",10,13,"ENTER 2 FOR BRUFEN ",10,13,"ENTER 3 FOR LOPRIN ",10,13,"ENTER 4 FOR PARACETALOM ",10,13,"ENTER 5 FOR PANADOL ",10,13,"ENTER 6 FOR AUGMENTIN ",10,13,"ENTER 0 TO RETURN TO MAIN MENU $" 
    USERCHOICE DB 10,13,10,13,"ENTER 1 TO CHECK THE PRODUCTS",10,13,"ENTER 2 TO CHECK WHICH PRODUCT HAS LOW STOCK",10,13, "ENTER 0 TO RETURN TO MAIN MENU $"
    QTY DB 10,13,10,13,"ENTER QUANTITY $"
    RECEIPT DB 10,13,10,13,"YOUR BILL IS: $"
    DISPLAY DB 10,13,10,13,"PRODUCT NAME     PRODUCT ID     PRODUCT PRICE$" 
    ANOTHER DB 10,13,10,13,"DO YOU WANT TO ADD ANY OTHER ITEM ?",10,13,"ENTER Y FOR YES AND N FOR NO!  $"
    M1 DB 10,13,     "1.PONSTAN          56458              10$"
    M2 DB 10,13,     "2.BRUFEN           13120              30$" 
    M3 DB 10,13,     "3.LOPRIN           12110              40$" 
    M4 DB 10,13,     "4.PARACETAMOL      55121              60$" 
    M5 DB 10,13,     "5.PANADOL          52521              50$" 
    M6 DB 10,13,     "6.AUGMENTIN        15541              100$" 
    TOTAL DW ?  
    PRO DB ?
    GTOTAL DW 0
    
    M1Q DW 60
    M2Q DW 30
    M3Q DW 200
    M4Q DW 400
    M5Q DW 10
    M6Q DW 82
    
    M1P DW 10
    M2P DW 30
    M3P DW 40   
    M4P DW 60 
    M5P DW 50 
    M6P DW 100 
    INVALIDMSG DB 10,13,10,13,"INVALID INPUT ! TRY AGAIN.$"  
    NOTSUFFICIENTMSG DB 10,13,10,13,"Product out of Stock $"
    
.CODE
    MAIN PROC 
        
            MOV AX, @DATA 
            MOV DS, AX  
            
            MOV AH, 9
            LEA DX, WELCOME
            INT 21H  
        
        RESTART:
        
            MOV AH, 9
            LEA DX, OPTION
            INT 21H
            
            MOV AH, 1
            INT 21H
            MOV BH, AL 
             
            CMP BH, "1"
            JE CALL PRODUCTSALE 
            
            CMP BH, "2"
            JE CALL PRODUCTDETAILS 
            
            CMP BH, "0"
            JE EXIT
            
            MOV AH, 9
            LEA DX, INVALIDMSG
            INT 21H 
            
            JMP RESTART 
         
        EXIT:
        
            MOV AH, 4CH
            INT 21H 
        
    MAIN ENDP     
    
                           
    PRODUCTSALE PROC
        
        MEDCHOICE:
        
            MOV AH, 9
            LEA DX, CUSTOMERCHOICE
            INT 21H
            
            MOV AH, 1
            INT 21H
            MOV PRO, AL
            
            CMP PRO, "0"
            JE RESTART 
            
            CMP PRO, "1"
            JL INVALIDC
              
            CMP PRO, "6"
            JG INVALIDC 
            
            CALL SALEPRO
        
        INVALIDC:
      
            MOV AH, 9
            LEA DX, INVALIDMSG
            INT 21H 
            
            JMP MEDCHOICE
        
    PRODUCTSALE ENDP 
               
    SALEPRO PROC
            
        AGAINN:  
        
            MOV AH, 9
            LEA DX, QTY
            INT 21H
       
            PUSH BX
            PUSH CX
            PUSH DX
             
        BEGIN: 
 
            XOR BX, BX
            XOR CX, CX
            
            MOV AH, 1
            INT 21H 
        
        REPEAT:  
    
            AND AX, 000FH
            PUSH AX  
            
            MOV AX, 10
            MUL BX
            POP BX 
            
            ADD BX, AX  
            
            MOV AH, 1
            INT 21H  
            
            CMP AL, 0DH
            JNE REPEAT 
            
            MOV AX, BX
            CMP CX, 0
            JE EXITT
            NEG AX 
            
        EXITT:
     
            POP DX
            POP CX
            POP BX 
                          
        BILL: 
               
            CMP PRO, "1"
            JE P1
            CMP PRO, "2"
            JE P2 
            CMP PRO, "3"
            JE P3 
            CMP PRO, "4"
            JE P4 
            CMP PRO, "5" 
            JE P5  
            CMP PRO, "6" 
            JE P6
                     
        P1:
              
            CMP AX, M1Q
            JG NOTSUFFICIENT 
            SUB M1Q, AX
             
            MOV CX, M1P 
            MUL CX 
            ADD GTOTAL, AX
            JMP ASKFORANOTHER
                      
        P2:
              
            CMP AX, M2Q
            JG NOTSUFFICIENT 
            SUB M2Q, AX
                 
            MOV CX, M2P 
            MUL CX   
            ADD GTOTAL, AX
            JMP ASKFORANOTHER 
          
        P3:      
            CMP AX, M3Q
            JG NOTSUFFICIENT 
            SUB M3Q, AX
              
            MOV CX, M3P 
            MUL CX 
            ADD GTOTAL, AX
            JMP ASKFORANOTHER           
             
        P4:        
            CMP AX, M4Q
            JG NOTSUFFICIENT 
            SUB M4Q, AX
              
            MOV CX, M4P 
            MUL CX   
            ADD GTOTAL, AX    
            JMP ASKFORANOTHER  
              
        P5:    
            CMP AX, M5Q
            JG NOTSUFFICIENT 
            SUB M5Q, AX
              
            MOV CX, M5P 
            MUL CX   
            ADD GTOTAL, AX
            JMP ASKFORANOTHER   
              
        P6:                       
            CMP AX, M6Q
            JG NOTSUFFICIENT 
            SUB M6Q, AX
               
            MOV CX, M6P 
            MUL CX 
            ADD GTOTAL, AX          
            JMP ASKFORANOTHER
              
        NOTSUFFICIENT:
            MOV AH, 9
            LEA DX, NOTSUFFICIENTMSG
            INT 21H
            JMP MEDCHOICE  
              
        ASKFORANOTHER:
                     
            PUSH AX
            MOV AH, 9
            LEA DX, ANOTHER
            INT 21H
              
            MOV AH, 1
            INT 21H
            MOV BL, AL  
             
            POP AX
              
            CMP BL, "Y" 
            JE MEDCHOICE
            CMP BL, "y"
            JE MEDCHOICE 
                      
            PUSH AX
            MOV AH, 9
            LEA DX, RECEIPT
            INT 21H           
            POP AX 
            
            MOV AX, GTOTAL
                                 
            PUSH AX
            PUSH BX
            PUSH CX
            PUSH DX
              
            CMP AX, 0
            JG ALPHA
              
            PUSH AX
              
            MOV DL,"-"
            MOV AH, 2
            INT 21H
              
            POP AX
            NEG AX
              
        ALPHA:
              
            XOR CX, CX
            MOV BX, 10
             
        WHILE_:
            XOR DX, DX
            DIV BX
            PUSH DX
              
            INC CX
              
            CMP AX, 0
            JNE WHILE_
              
            MOV AH, 2
              
        PRINT: 
        
            POP DX
            ADD DL, 48
            INT 21H 
            
            LOOP PRINT 
            
            POP DX
            POP CX
            POP BX 
            POP AX
            
            MOV GTOTAL, 0  
            JMP RESTART
                     
    SALEPRO ENDP   
       
              
    PRODUCTDETAILS PROC 
              
        AGAINU:
              
            MOV AH, 9
            LEA DX, USERCHOICE
            INT 21H
              
            MOV AH, 1
            INT 21H
            MOV CL, AL
              
            CMP CL, "1"
            JE CALL CHECKPRODUCTS  
            
            CMP CL, "2"
            JE CALL LOWSTOCK 
            
            CMP CL, "0"
            JE RESTART 
              
            JMP INVALIDU
 
        INVALIDU:
        
            MOV AH, 9
            LEA DX, INVALIDMSG
            INT 21H
            JMP AGAINU
                
    PRODUCTDETAILS ENDP
                    
                    
    CHECKPRODUCTS PROC 
              
            MOV AH, 9
            LEA DX, DISPLAY
            INT 21H   
            
            LEA DX, M1
            INT 21H 
            
            LEA DX, M2
            INT 21H  
            
            LEA DX, M3
            INT 21H
                     
            LEA DX, M4
            INT 21H 
           
            LEA DX, M5
            INT 21H 
           
            LEA DX, M6
            INT 21H 
            JMP AGAINU
                   
    CHECKPRODUCTS ENDP 
          
    LOWSTOCK PROC

             MOV AH, 9
             LEA DX, DISPLAY
             INT 21H 
            
             CMP M1Q,50
             JL LOW1  
             
        CHECK1:
             CMP M2Q,50
             JL LOW2
             
        CHECK2:
             CMP M3Q,50
             JL LOW3
             
        CHECK3:    
             CMP M4Q,50
             JL LOW4
             
        CHECK4:
             CMP M5Q,50
             JL LOW5
        
        CHECK5:
             CMP M6Q,50
             JL LOW6
          
             JMP AGAINU
             
        LOW1:  
             MOV AH, 9
             LEA DX, M1
             INT 21H 
             JMP CHECK1
    
        LOW2:
             MOV AH, 9
             LEA DX, M2
             INT 21H
             JMP CHECK2
    
        LOW3:
             MOV AH, 9
             LEA DX, M3
             INT 21H 
             JMP CHECK3 
    
        LOW4:
             MOV AH, 9
             LEA DX, M4
             INT 21H
             JMP CHECK4
    
        LOW5:
             MOV AH, 9
             LEA DX, M5
             INT 21H 
             JMP CHECK5
            
        LOW6:
             MOV AH, 9
             LEA DX, M6
             INT 21H    
             JMP AGAINU
    LOWSTOCK ENDP  
    
END MAIN


